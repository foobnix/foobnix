cd ../
sudo python setup.py install

